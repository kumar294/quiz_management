# QUIZMANAGEMENT-Navigus-assignment
Navigus assignment of quiz

# SCREEN SHOTS

![Screenshot (155)](https://user-images.githubusercontent.com/63440512/117760586-8478e300-b243-11eb-98c9-da69cadc7934.png)


![Screenshot (156)](https://user-images.githubusercontent.com/63440512/117760656-ab371980-b243-11eb-8b1b-e0d5798c9dc5.png)


![Screenshot (157)](https://user-images.githubusercontent.com/63440512/117760742-d4f04080-b243-11eb-8af8-98e877cc8e7a.png)


![Screenshot (158)](https://user-images.githubusercontent.com/63440512/117760812-f05b4b80-b243-11eb-9239-c537bb4181bd.png)


![Screenshot (159)](https://user-images.githubusercontent.com/63440512/117760883-0b2dc000-b244-11eb-864e-851447a91ca2.png)


![Screenshot (160)](https://user-images.githubusercontent.com/63440512/117760957-27c9f800-b244-11eb-9017-6a160df2d3b8.png)


![Screenshot (161)](https://user-images.githubusercontent.com/63440512/117760991-387a6e00-b244-11eb-8f0f-83fb0ce053cf.png)

# STUDENT EXAM AND MARKS 

![Screenshot (162)](https://user-images.githubusercontent.com/63440512/117761303-c191a500-b244-11eb-837d-fa66cf98b10d.png)



![Screenshot (163)](https://user-images.githubusercontent.com/63440512/117761199-96a75100-b244-11eb-98a7-8f18b38bc608.png)


![Screenshot (164)](https://user-images.githubusercontent.com/63440512/117761422-f43b9d80-b244-11eb-8671-55b244056e3a.png)



# BEFORE RUNNING CHECK REQUIREMENTS OR INSTALL BELOW MENTIONED 

install python

install django

install django-widget-tweaks

install check-requirements-txt

install Pillow

# Then run this commands

 python3 manage.py makemigrations or  py manage.py makemigrations
 
 python3 manage.py migrate or py manage.py migrate
 
#The below is to create superuser

 py manage.py createsuperuser or python3 manage.py createsuperuser

#The below is to run the server at last

 python3 manage.py runserver or py manage.py runserver
